# Trabajo practico manipulacion y consulta de datos 

- Realizamos en clase el trabajo practico para consultas a futuro